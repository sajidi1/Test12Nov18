﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Baseball
{
    // Sorry couldn't spend much time on this.  But if I had more time, these are some out of many improvements which I would have done:    
    // TODO: Input validation
    // TODO: Refactor to apply SOLID.  At the very least, divide the code in methods/files
    // TODO: In HandleX() the spec doesn't specify what to do if stack doesn't have any last item. So assuming it'll always have a last item
    // TODO: In HandlePlus() the spec doesn't specify what to do if stack doesn't have last 2 items. So assuming it'll always have at least 2 last items        
    // TODO: Provide a brief summary of what Handle methods do and comments at other similar places
    // TODO: I didn't feel the need of second parameter (n) for these v.simple test cases. May be it is required for extreme cases. 
    class Program
    {
        public static Stack<int> stackPreviousScores = new Stack<int>(); 

        static void Main(string[] args)
        {
            Console.WriteLine(@"Start: Enter the blocks separated by comma 
(e.g. 5, -2, 4, Z, X, 9, +, +) and hit enter:
");
            
            string[] blocks = Console.ReadLine().Split(new char[] { ',' });       

            ComputeTotal(blocks);

            Console.WriteLine("End. Hit any key to exit.");
            Console.ReadLine();
        }

        private static void ComputeTotal(string[] blocks)
        {            
            int total = 0;

            foreach (string currentHit in blocks)
            {
                int i = 0;
                if (IsANumber(currentHit, out i))
                {
                    // A number
                    int currentScore = i;
                    total += currentScore;

                    stackPreviousScores.Push(currentScore);
                }
                else
                {
                    // A character
                    switch (currentHit.Trim().ToLower())
                    {
                        case "x":
                            HandleX(ref total);
                            break;

                        case "+":
                            HandlePlus(ref total);
                            break;

                        case "z":
                            HandleZ(ref total);
                            break;

                        default:
                            HandleInvalid(currentHit);
                            break;
                    }
                }
            }

            Console.WriteLine("Total is: {0}", total);
        }

        private static bool IsANumber(string currentHit, out int i)
        {
            return int.TryParse(currentHit, out i);
        }

        private static void HandleX(ref int total)
        {
            int lastScore = stackPreviousScores.Peek();

            int currentScore = 2 * lastScore;

            total += currentScore;

            stackPreviousScores.Push(currentScore);
        }

        private static void HandlePlus(ref int total)
        {
            int lastScore = stackPreviousScores.Pop();
            int secondLastScore = stackPreviousScores.Pop();
           
            int currentScore = lastScore + secondLastScore;

            total += currentScore;

            stackPreviousScores.Push(lastScore);
            stackPreviousScores.Push(currentScore);
        }

        private static void HandleZ(ref int total)
        {
            int lastScore = stackPreviousScores.Pop();

            total -= lastScore;            
        }

        private static void HandleInvalid(string currentHit)
        {
            Console.WriteLine("Invalid block found -> {0}", currentHit);
        }
    }
}
