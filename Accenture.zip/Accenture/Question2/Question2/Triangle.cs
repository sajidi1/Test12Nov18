﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    class Triangle : Shape
    {       
        ILogger _logger;

        public Triangle(ILogger logger)
        {
            _logger = logger;
        }

        public override void Area()
        {
            _logger.Log("triangle", IsPolygon);
        }

        public override bool IsPolygon
        {
            get
            {
                return true;
            }
            set
            {
                base.IsPolygon = value;
            }
        }
    }
}
