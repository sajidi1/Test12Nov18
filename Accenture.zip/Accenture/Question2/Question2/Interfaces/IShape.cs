﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2.Interfaces
{
    public interface IShape
    {
        void Area(); 

        double Perimeter { get; set; }
        
        bool IsPolygon { get; set; }
    }
}
