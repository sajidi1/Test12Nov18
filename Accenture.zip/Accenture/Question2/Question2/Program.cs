﻿using Question2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    // Sorry couldn't spend much time on this.  But if I had more time, these are some out of many improvements which I would have done:    
    // TODO: Another class which inherits from ILogger called FileLogger and implement one liner to log to a file
    // TODO: Move + Organise the files into logical folders
    // TODO: IsPolygon was thought and implemented only in the last 3 mins. There are better solutions possible!
    class Program
    {
        static void Main(string[] args)
        {
            ILogger logger = new ConsoleLogger();

            List<IShape> shapes = new List<IShape>() 
            {
                new Circle(logger),
                new Rectangle(logger),
                new Triangle(logger)
            };

            foreach (var shape in shapes)
            {
                shape.Area();
            }

            Console.WriteLine("Hit Enter to exit");
            Console.ReadLine();
        }
    }
}
