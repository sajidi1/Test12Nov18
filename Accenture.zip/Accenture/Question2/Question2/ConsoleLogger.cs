﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    public class ConsoleLogger : ILogger
    {
        public void Log(string shapeName, bool isPolygon)
        {
            Console.Write("{0}: Area method for {1} invoked.", DateTime.Now, shapeName);

            Console.WriteLine("Is Polygon: {0}", isPolygon);
        }
    }
}
