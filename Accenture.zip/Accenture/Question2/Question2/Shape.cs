﻿using Question2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    public abstract class Shape : IShape
    {
        public double _perimeter;

        public abstract void Area();

        public bool _isPolygon;

        public double Perimeter
        {
            get
            {
                return _perimeter;
            }
            set
            {
                _perimeter = value;
            }
        }


        public virtual bool IsPolygon
        {
            get
            {
                return _isPolygon;
            }
            set
            {
                _isPolygon = value;
            }
        }
    }  
}
