﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    public class Circle : Shape
    {        
        ILogger _logger;

        public Circle(ILogger logger)
        {
            _logger = logger;
        }

        public override void Area()
        {
            _logger.Log("circle", IsPolygon);
        }

        public override bool IsPolygon
        {
            get
            {
                return false;
            }
            set
            {
                base.IsPolygon = value;
            }
        }
    }  
}
