﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    public class Rectangle : Shape
    {
        ILogger _logger;

        public Rectangle(ILogger logger)
        {
            _logger = logger;
        }

        public override void Area()
        {
            _logger.Log("rectangle", IsPolygon);
        }

        public override bool IsPolygon
        {
            get
            {
                return true;
            }
            set
            {
                base.IsPolygon = value;
            }
        }
    }  
}
